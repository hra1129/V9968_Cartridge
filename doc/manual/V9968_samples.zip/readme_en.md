# V9968 Sample Programs

Sample programs from the "V9968 User's Manual".
Each sample is written in assembly language for zma (the Z80/R800
cross macro assembler) and runs as a 16 KB cartridge ROM (4000h-).
Both the source (.asm) and the built ROM (.rom) are included.

## Sample list

| File | Manual section | Description |
|---|---|---|
| cmd_demo.asm | 8.18 | VDP command basics (HMMV / LINE / LMMM, SCREEN 5) |
| pal_demo.asm | 7.5 | Rewriting the palette (R#16 + palette port) |
| spr_demo.asm | 6.4.6 | Sprite mode 2 (per-line colors) |
| g7_demo.asm | 5.12 | Graphic 7 (SCREEN 8) 256-color display |
| spr3_demo.asm | 6.5.5 | Sprite mode 3 (per-dot colors, scaling, flipping, translucency) |
| lrmm_demo.asm | 8.19 | Rotated copy with LRMM (30-degree rotation, compared with LMMM) |
| lfmm_demo.asm | 8.20 | Font drawing with LFMM |
| line_demo.asm | 10.7 | Screen split using the line interrupt (R#19) |

## Building

zma is required (https://github.com/hra1129/zma).
The sources include "msx.asm" from zma's own include folder.

Run zma in the folder containing the sources, using relative
file names:

```
zma cmd_demo.asm cmd_demo.rom
```

zma's output is the actual code size. The bundled .rom files are
padded with zeros to 16 KB.

## Running

A system equipped with the V9968 is required. With the V9968 build
of openMSX, the samples can be started as a cartridge on a machine
with a built-in V9968 (such as C-BIOS_V9968_JP):

```
openmsx -machine C-BIOS_V9968_JP -cart cmd_demo.rom
```
