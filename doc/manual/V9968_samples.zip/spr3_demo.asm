; -----------------------------------------------------------------------------
;	spr3_demo.asm -- Sprite mode 3 demonstration (V9968 User's Manual, ch.6)
;
;	SCREEN 5 (Graphic 4) with sprite mode 3 (R#20 SP3 = 1).
;	Mode 3 patterns carry a 4-bit color code per dot, and each
;	plane has its own display size (MGX/MGY), flip bits (RVX/RVY)
;	and transparency (TP). Two 16x16 tiles are used:
;
;	  plane 0: arrow, x1 size (16x16)
;	  plane 1: arrow, x2 size (32x32)
;	  plane 2: arrow, x3 size (48x48)
;	  plane 3: arrow, x2, flipped horizontally (RVX = 1)
;	  plane 4: arrow, x2, flipped vertically (RVY = 1)
;	  plane 5: ball, 40x40, TP = 2 (50% blend) over a magenta box
;	  plane 6: Y = 216 terminates the list
;
;	The arrow is asymmetric (blue stripe on top, red head on the
;	right), so both flips are easy to see.
;
;	Mode 3 patterns live in a "pattern sheet" laid out like a
;	Graphic 4 bitmap: 256 dots (128 bytes) per line from the
;	pattern base (R#6, here the SCREEN 5 default 7800h). A 16x16
;	tile therefore occupies 8 bytes of every sheet line, and the
;	rows are written with a 128-byte stride.
;
;	Sprite mode 3 needs extended mode (V58 = 0) for its registers;
;	R#20/R#21 are locked at reset, so the lock is released first
;	(Port#4 bit7 = 0).
;
;	Assemble with zma, run as a cartridge ROM (16 KB, 4000h).
; -----------------------------------------------------------------------------

		include		"msx.asm"

		org		0x4000
		rom_header	entry_point

; -----------------------------------------------------------------------------
;	entry point
; -----------------------------------------------------------------------------
entry_point::
		di
		ld		sp, 0xf380

		; release the extended-register lock (Port#4 bit7 = 0)
		xor		a, a
		out		[0x9c], a

		; SCREEN 5
		ld		a, 5
		call		CHGMOD

		; extended mode: R#21 bit0 (V58) = 0
		ld		a, 0x3a
		ld		b, 21
		call		vdp_reg

		; sprite mode 3: R#20 bit3 (SP3) = 1
		ld		a, 0x08
		ld		b, 20
		call		vdp_reg

		; set the sprite table bases explicitly, after selecting
		; sprite mode 3 (the BIOS default attribute base differs
		; between BIOS implementations):
		; attribute table = 7600h, pattern sheet = 7800h
		ld		a, 0xed			; R#5: SAT base 7600h
		ld		b, 5
		call		vdp_reg
		ld		a, 0			; R#11: SAT base high bits = 0
		ld		b, 11
		call		vdp_reg
		ld		a, 0x0f			; R#6: pattern base 7800h
		ld		b, 6
		call		vdp_reg

		; ---- background: fill the screen with color 1
		ld		hl, 0
		ld		b, 36
		call		vdp_reg16
		ld		hl, 0
		ld		b, 38
		call		vdp_reg16
		ld		hl, 256
		ld		b, 40
		call		vdp_reg16
		ld		hl, 212
		ld		b, 42
		call		vdp_reg16
		ld		a, 0x11			; color 1 in both nibbles
		ld		b, 44
		call		vdp_reg
		ld		a, 0			; ARG = 0
		ld		b, 45
		call		vdp_reg
		ld		a, 0xc0			; HMMV
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; ---- magenta box (140,96), 90x64 -- the blend target
		ld		hl, 140
		ld		b, 36
		call		vdp_reg16
		ld		hl, 96
		ld		b, 38
		call		vdp_reg16
		ld		hl, 90
		ld		b, 40
		call		vdp_reg16
		ld		hl, 64
		ld		b, 42
		call		vdp_reg16
		ld		a, 0xdd			; color 13 in both nibbles
		ld		b, 44
		call		vdp_reg
		ld		a, 0xc0			; HMMV (ARG is still 0)
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; ---- pattern tiles -> pattern sheet at 7800h
		ld		hl, tile_arrow
		ld		de, 0x7800		; tile (PX=0, PY=0)
		call		write_tile
		ld		hl, tile_ball
		ld		de, 0x7808		; tile (PX=1, PY=0): +8 bytes
		call		write_tile

		; ---- attributes -> 7600h (SCREEN 5 default base)
		ld		de, 0x7600
		ld		hl, attribute_table
		ld		bc, 56			; 7 planes x 8 bytes
		call		vram_copy

main_loop::
		jr		main_loop

; -----------------------------------------------------------------------------
;	mode 3 attribute table: 8 bytes per plane
;	+0 Y, +1 SZ/Y9-8, +2 MGY, +3 TP/RVY/RVX/PS, +4 X,
;	+5 PTS/X9-8, +6 MGX, +7 PY/PX
; -----------------------------------------------------------------------------
attribute_table:
		; plane 0: arrow x1 at (24, 36)
		db		36, 0x00, 16, 0x00, 24, 0x00, 16, 0x00
		; plane 1: arrow x2 at (64, 36)
		db		36, 0x00, 32, 0x00, 64, 0x00, 32, 0x00
		; plane 2: arrow x3 at (120, 28)
		db		28, 0x00, 48, 0x00, 120, 0x00, 48, 0x00
		; plane 3: arrow x2, RVX (points left) at (24, 110)
		db		110, 0x00, 32, 0x10, 24, 0x00, 32, 0x00
		; plane 4: arrow x2, RVY (stripe at bottom) at (80, 110)
		db		110, 0x00, 32, 0x20, 80, 0x00, 32, 0x00
		; plane 5: ball 40x40, TP = 2 (50%), at (150, 104)
		db		104, 0x00, 40, 0x80, 150, 0x00, 40, 0x01
		; plane 6: terminator
		db		216, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

; -----------------------------------------------------------------------------
;	tile data: 16 rows x 8 bytes (4 bits per dot, high nibble first)
;	colors: 5 = light blue, 0xB = yellow, 8 = red, 0xF = white
; -----------------------------------------------------------------------------
tile_arrow:
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
		db		0x00, 0x55, 0x55, 0x55, 0x55, 0x55, 0x00, 0x00
		db		0x00, 0x55, 0x55, 0x55, 0x55, 0x55, 0x00, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x88, 0x00, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x88, 0x88, 0x00
		db		0x0b, 0xbb, 0xbb, 0xbb, 0xbb, 0x88, 0x88, 0x00
		db		0x0b, 0xbb, 0xbb, 0xbb, 0xbb, 0x88, 0x88, 0x80
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x88, 0x88, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x88, 0x88, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x88, 0x00, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

tile_ball:
		db		0x00, 0x00, 0x08, 0x88, 0x88, 0x80, 0x00, 0x00
		db		0x00, 0x08, 0x88, 0x88, 0x88, 0x88, 0x80, 0x00
		db		0x00, 0x88, 0x8b, 0xbb, 0xbb, 0xb8, 0x88, 0x00
		db		0x08, 0x88, 0xbb, 0xff, 0xff, 0xbb, 0x88, 0x00
		db		0x08, 0x8b, 0xbf, 0xff, 0xff, 0xfb, 0xb8, 0x80
		db		0x08, 0x8b, 0xbf, 0xff, 0xff, 0xfb, 0xb8, 0x80
		db		0x08, 0x88, 0xbb, 0xff, 0xff, 0xbb, 0x88, 0x00
		db		0x00, 0x88, 0x8b, 0xbb, 0xbb, 0xb8, 0x88, 0x00
		db		0x00, 0x08, 0x88, 0x88, 0x88, 0x88, 0x80, 0x00
		db		0x00, 0x00, 0x08, 0x88, 0x88, 0x80, 0x00, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
		db		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

; -----------------------------------------------------------------------------
;	write one 16x16 tile into the pattern sheet.
;	the sheet has 128 bytes per line, so each tile row is written
;	at a 128-byte stride.
;	in:  HL = tile data (16 rows x 8 bytes), DE = sheet address
; -----------------------------------------------------------------------------
write_tile::
		ld		b, 16			; 16 rows
wt_row:
		push		bc
		push		de
		call		vram_addr		; set VRAM write address from DE
		pop		de
		ld		c, 8			; 8 bytes per row
wt_byte:
		ld		a, [hl]
		out		[0x98], a
		inc		hl
		dec		c
		jr		nz, wt_byte
		ex		de, hl			; DE += 128 (next sheet line)
		ld		bc, 128
		add		hl, bc
		ex		de, hl
		pop		bc
		djnz		wt_row
		ret

; -----------------------------------------------------------------------------
;	set the VRAM write address
;	in:  DE = VRAM address
; -----------------------------------------------------------------------------
vram_addr::
		ld		a, d			; R#14 = address bits 16..14
		and		a, 0xc0
		rlca
		rlca
		ld		b, 14
		call		vdp_reg
		ld		a, e			; low byte of the address
		out		[0x99], a
		ld		a, d			; high byte + write flag (bit6)
		and		a, 0x3f
		set		6, a
		out		[0x99], a
		ret

; -----------------------------------------------------------------------------
;	write one VDP control register (direct register write)
;	in:  A = value, B = register number
; -----------------------------------------------------------------------------
vdp_reg::
		out		[0x99], a
		ld		a, b
		set		7, a
		out		[0x99], a
		ret

; -----------------------------------------------------------------------------
;	write a 16-bit command parameter
;	in:  HL = value, B = register number of the low byte
; -----------------------------------------------------------------------------
vdp_reg16::
		ld		a, l
		call		vdp_reg
		inc		b
		ld		a, h
		call		vdp_reg
		ret

; -----------------------------------------------------------------------------
;	wait until the running VDP command finishes (S#2 CE bit = 0)
; -----------------------------------------------------------------------------
vdp_wait::
		ld		a, 2			; select status register 2
		ld		b, 15
		call		vdp_reg
vdp_wait_loop:
		in		a, [0x99]
		bit		0, a			; CE bit
		jr		nz, vdp_wait_loop
		xor		a, a			; restore S#0 selection
		ld		b, 15
		call		vdp_reg
		ret

; -----------------------------------------------------------------------------
;	copy data to VRAM
;	in:  DE = VRAM address, HL = source address, BC = byte count
; -----------------------------------------------------------------------------
vram_copy::
		push		hl
		push		bc
		ex		de, hl			; HL = VRAM address
		ld		a, h			; R#14 = address bits 16..14
		and		a, 0xc0
		rlca
		rlca
		ld		b, 14
		call		vdp_reg
		ld		a, l			; low byte of the address
		out		[0x99], a
		ld		a, h			; high byte + write flag (bit6)
		and		a, 0x3f
		set		6, a
		out		[0x99], a
		pop		bc
		pop		hl
vram_copy_loop:
		ld		a, [hl]
		out		[0x98], a
		inc		hl
		dec		bc
		ld		a, b
		or		a, c
		jr		nz, vram_copy_loop
		ret
