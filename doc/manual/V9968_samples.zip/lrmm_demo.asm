; -----------------------------------------------------------------------------
;	lrmm_demo.asm -- LRMM rotation demonstration (V9968 User's Manual, ch.8)
;
;	SCREEN 5 (Graphic 4). A 64x64 pattern is drawn at the left of the
;	screen, then LRMM copies it to the right, rotated by 30 degrees.
;	Below the rotated copy, a plain LMMM copy of the same pattern is
;	placed for comparison.
;
;	LRMM parameters used here:
;	  rotation vector (VX, VY) = (221, 128) for theta = 30 degrees
;	    VX = INT(256 * cos 30) = 221, VY = INT(256 * sin 30) = 128
;	  reference start point (SX, SY) = (36, 13): chosen so that the
;	    rotated sampling parallelogram is centered on the source box
;	    (16,24)-(79,87); the reference point is NOT the center itself.
;	  window (WSX, WSY)-(WEX, WEY) = the source box itself; samples
;	    that fall outside the window use the CLR color (here the
;	    background color 4), so the corners of the destination that
;	    would read outside the pattern simply stay background.
;
;	LRMM is a V9968 extended command: it needs extended mode
;	(V58 = 0). R#20/R#21 are locked at reset (LockExtReg = 1), so
;	the lock is released first by writing bit7 = 0 to Port#4.
;
;	Assemble with zma, run as a cartridge ROM (16 KB, 4000h).
; -----------------------------------------------------------------------------

		include		"msx.asm"

		org		0x4000
		rom_header	entry_point

; -----------------------------------------------------------------------------
;	entry point
; -----------------------------------------------------------------------------
entry_point::
		di
		ld		sp, 0xf380

		; release the extended-register lock (Port#4 bit7 = 0)
		xor		a, a
		out		[0x9c], a

		; SCREEN 5
		ld		a, 5
		call		CHGMOD

		; extended mode: R#21 bit0 (V58) = 0
		; (bits 7..1 of R#21 are the fixed pattern 0,0,1,1,1,0,1)
		ld		a, 0x3a
		ld		b, 21
		call		vdp_reg

		; ---- fill the whole screen with color 4 (dark blue)
		ld		hl, 0
		ld		b, 36
		call		vdp_reg16
		ld		hl, 0
		ld		b, 38
		call		vdp_reg16
		ld		hl, 256
		ld		b, 40
		call		vdp_reg16
		ld		hl, 212
		ld		b, 42
		call		vdp_reg16
		ld		a, 0x44			; CLR: color 4 in both nibbles
		ld		b, 44
		call		vdp_reg
		ld		a, 0			; ARG = 0
		ld		b, 45
		call		vdp_reg
		ld		a, 0xc0			; HMMV
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; ---- draw the source pattern: box (16,24), 64x64
		; white base
		ld		hl, 16
		ld		b, 36
		call		vdp_reg16
		ld		hl, 24
		ld		b, 38
		call		vdp_reg16
		ld		hl, 64
		ld		b, 40
		call		vdp_reg16
		ld		hl, 64
		ld		b, 42
		call		vdp_reg16
		ld		a, 0xff			; color 15 in both nibbles
		ld		b, 44
		call		vdp_reg
		ld		a, 0xc0			; HMMV (ARG is still 0)
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; red top half: (16,24), 64x32
		ld		hl, 16
		ld		b, 36
		call		vdp_reg16
		ld		hl, 24
		ld		b, 38
		call		vdp_reg16
		ld		hl, 64
		ld		b, 40
		call		vdp_reg16
		ld		hl, 32
		ld		b, 42
		call		vdp_reg16
		ld		a, 0x88			; color 8 in both nibbles
		ld		b, 44
		call		vdp_reg
		ld		a, 0xc0			; HMMV
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; yellow corner block: (16,24), 16x16 (top-left)
		ld		hl, 16
		ld		b, 36
		call		vdp_reg16
		ld		hl, 24
		ld		b, 38
		call		vdp_reg16
		ld		hl, 16
		ld		b, 40
		call		vdp_reg16
		ld		hl, 16
		ld		b, 42
		call		vdp_reg16
		ld		a, 0xbb			; color 11 in both nibbles
		ld		b, 44
		call		vdp_reg
		ld		a, 0xc0			; HMMV
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; blue corner block: (64,72), 16x16 (bottom-right)
		ld		hl, 64
		ld		b, 36
		call		vdp_reg16
		ld		hl, 72
		ld		b, 38
		call		vdp_reg16
		ld		hl, 16
		ld		b, 40
		call		vdp_reg16
		ld		hl, 16
		ld		b, 42
		call		vdp_reg16
		ld		a, 0x22			; color 2 in both nibbles
		ld		b, 44
		call		vdp_reg
		ld		a, 0xc0			; HMMV
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; ---- LRMM: copy the pattern to (150,24), rotated by 30 degrees
		ld		hl, 36			; SX = 36 (reference start point)
		ld		b, 32
		call		vdp_reg16
		ld		hl, 13			; SY = 13
		ld		b, 34
		call		vdp_reg16
		ld		hl, 150			; DX = 150
		ld		b, 36
		call		vdp_reg16
		ld		hl, 24			; DY = 24
		ld		b, 38
		call		vdp_reg16
		ld		hl, 64			; NX = 64
		ld		b, 40
		call		vdp_reg16
		ld		hl, 64			; NY = 64
		ld		b, 42
		call		vdp_reg16
		ld		a, 4			; CLR = 4: color used outside the window
		ld		b, 44
		call		vdp_reg
		ld		a, 0			; ARG = 0
		ld		b, 45
		call		vdp_reg
		ld		hl, 221			; VX = INT(256 * cos 30 deg) = 221
		ld		b, 47
		call		vdp_reg16
		ld		hl, 128			; VY = INT(256 * sin 30 deg) = 128
		ld		b, 49
		call		vdp_reg16
		ld		hl, 16			; WSX = 16
		ld		b, 51
		call		vdp_reg16
		ld		hl, 24			; WSY = 24
		ld		b, 53
		call		vdp_reg16
		ld		hl, 79			; WEX = 79
		ld		b, 55
		call		vdp_reg16
		ld		hl, 87			; WEY = 87
		ld		b, 57
		call		vdp_reg16
		ld		a, 0x30			; LRMM, LOP = IMP
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; ---- LMMM: plain copy of the pattern to (150,120)
		ld		hl, 16			; SX = 16
		ld		b, 32
		call		vdp_reg16
		ld		hl, 24			; SY = 24
		ld		b, 34
		call		vdp_reg16
		ld		hl, 150			; DX = 150
		ld		b, 36
		call		vdp_reg16
		ld		hl, 120			; DY = 120
		ld		b, 38
		call		vdp_reg16
		ld		hl, 64			; NX = 64
		ld		b, 40
		call		vdp_reg16
		ld		hl, 64			; NY = 64
		ld		b, 42
		call		vdp_reg16
		ld		a, 0			; ARG = 0
		ld		b, 45
		call		vdp_reg
		ld		a, 0x90			; LMMM, LOP = IMP
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

main_loop::
		jr		main_loop

; -----------------------------------------------------------------------------
;	write one VDP control register (direct register write)
;	in:  A = value, B = register number
; -----------------------------------------------------------------------------
vdp_reg::
		out		[0x99], a
		ld		a, b
		set		7, a
		out		[0x99], a
		ret

; -----------------------------------------------------------------------------
;	write a 16-bit command parameter
;	in:  HL = value, B = register number of the low byte
; -----------------------------------------------------------------------------
vdp_reg16::
		ld		a, l
		call		vdp_reg
		inc		b
		ld		a, h
		call		vdp_reg
		ret

; -----------------------------------------------------------------------------
;	wait until the running VDP command finishes (S#2 CE bit = 0)
; -----------------------------------------------------------------------------
vdp_wait::
		ld		a, 2			; select status register 2
		ld		b, 15
		call		vdp_reg
vdp_wait_loop:
		in		a, [0x99]
		bit		0, a			; CE bit
		jr		nz, vdp_wait_loop
		xor		a, a			; restore S#0 selection
		ld		b, 15
		call		vdp_reg
		ret
