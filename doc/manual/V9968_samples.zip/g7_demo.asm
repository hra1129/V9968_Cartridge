; -----------------------------------------------------------------------------
;	g7_demo.asm -- Graphic 7 (SCREEN 8) 256-color demonstration
;	               (V9968 User's Manual, ch.5)
;
;	In Graphic 7 each byte in VRAM is one dot, holding the color
;	directly as G3 R3 B2 bits -- no palette is involved. This sample
;	fills the whole screen with all 256 colors at once: the screen
;	is divided into an 8x8 grid of blocks, the block column selects
;	G (0..7), the block row selects R (0..7), and inside a block
;	four vertical stripes select B (0..3). 8 x 8 x 4 = 256 colors.
;
;	The picture is written by the CPU straight through the VRAM
;	data port, one byte per dot.
;
;	Assemble with zma, run as a cartridge ROM (16 KB, 4000h).
; -----------------------------------------------------------------------------

		include		"msx.asm"

		org		0x4000
		rom_header	entry_point

; -----------------------------------------------------------------------------
;	entry point
; -----------------------------------------------------------------------------
entry_point::
		di
		ld		sp, 0xf380

		; SCREEN 8 (Graphic 7)
		ld		a, 8
		call		CHGMOD

		; set the VRAM write address to 0
		xor		a, a			; R#14 = 0 (address bits 16..14)
		ld		b, 14
		call		vdp_reg
		xor		a, a			; address low byte = 0
		out		[0x99], a
		ld		a, 0x40			; address high byte = 0, write mode
		out		[0x99], a

		; draw 8 block rows of 26 lines (208 lines), R = 0..7
		ld		e, 0			; E = R (red level of the block row)
block_loop:
		ld		d, 26			; 26 lines per block row
line_loop:
		call		draw_line
		dec		d
		jr		nz, line_loop
		inc		e
		ld		a, e
		cp		a, 8
		jr		nz, block_loop

		; the remaining 4 lines (208..211) keep R = 7
		ld		d, 4
extra_loop:
		call		draw_line
		dec		d
		jr		nz, extra_loop

main_loop::
		jr		main_loop

; -----------------------------------------------------------------------------
;	draw one 256-dot line.
;	the G level comes from the block column (x / 32), the B level
;	from the stripe inside the block ((x / 8) mod 4), R from E.
;	in:  E = R (0..7).  clobbers A, C, H, L.
; -----------------------------------------------------------------------------
draw_line::
		ld		c, 0			; C = G (block column, 0..7)
g_loop:
		ld		l, 0			; L = B (stripe, 0..3)
b_loop:
		; color byte = (G << 5) | (R << 2) | B
		ld		a, c
		sla		a
		sla		a
		sla		a
		sla		a
		sla		a			; A = G << 5
		ld		h, a
		ld		a, e
		sla		a
		sla		a			; A = R << 2
		or		a, h
		or		a, l			; A = the dot's color byte
		ld		h, 8			; one stripe is 8 dots wide
px_loop:
		out		[0x98], a		; write one dot (address auto-increments)
		dec		h
		jr		nz, px_loop
		inc		l
		ld		a, l
		cp		a, 4
		jr		nz, b_loop
		inc		c
		ld		a, c
		cp		a, 8
		jr		nz, g_loop
		ret

; -----------------------------------------------------------------------------
;	write one VDP control register (direct register write)
;	in:  A = value, B = register number
; -----------------------------------------------------------------------------
vdp_reg::
		out		[0x99], a
		ld		a, b
		set		7, a
		out		[0x99], a
		ret
