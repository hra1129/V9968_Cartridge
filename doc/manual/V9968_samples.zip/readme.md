# V9968 サンプルプログラム集

『V9968 User's Manual』に掲載したサンプルプログラムのアーカイブです。
各サンプルは zma（Z80/R800 クロスマクロアセンブラ）用のソースコードで、
16KB のカートリッジ ROM（4000h〜）として動作します。
ソース（.asm）とビルド済み ROM（.rom）が同梱されています。

## サンプル一覧

| ファイル | 対応する節 | 内容 |
|---|---|---|
| cmd_demo.asm | §8.18 | VDP コマンドの基本（HMMV / LINE / LMMM、SCREEN 5） |
| pal_demo.asm | §7.5 | パレットの書き換え（R#16＋パレットポート） |
| spr_demo.asm | §6.4.6 | スプライトモード2（ラインごとの色設定） |
| g7_demo.asm | §5.12 | Graphic 7（SCREEN 8）の 256 色表示 |
| spr3_demo.asm | §6.5.5 | スプライトモード3（ドットごとの色、拡大・反転、半透明） |
| lrmm_demo.asm | §8.19 | LRMM による回転コピー（30°回転と LMMM との比較） |
| lfmm_demo.asm | §8.20 | LFMM によるフォント描画 |
| line_demo.asm | §10.7 | ライン割り込み（R#19）による画面分割 |

## ビルド方法

zma が必要です（https://github.com/hra1129/zma）。
ソースは zma 本体の `include/msx.asm` を参照しています。

ソースのあるフォルダで、相対ファイル名で実行してください。

```
zma cmd_demo.asm cmd_demo.rom
```

zma の出力はコード実サイズです。同梱の .rom は 16KB に
0 でパディングしたものです。

## 実行方法

V9968 を搭載した環境が必要です。openMSX の V9968 対応ビルドでは、
内蔵 V9968 マシン（C-BIOS_V9968_JP など）でカートリッジとして
起動できます。

```
openmsx -machine C-BIOS_V9968_JP -cart cmd_demo.rom
```
