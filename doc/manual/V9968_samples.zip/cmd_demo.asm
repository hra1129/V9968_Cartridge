; -----------------------------------------------------------------------------
;	cmd_demo.asm -- VDP command demonstration (V9968 User's Manual, ch.8)
;
;	SCREEN 5 (Graphic 4) demo using three kinds of VDP commands:
;	  1. HMMV : fill the whole screen, then fill a box
;	  2. LINE : draw a frame and a cross (X) inside the box
;	  3. LMMM : copy the finished box to another place on the screen
;
;	Assemble with zma, run as a cartridge ROM (16 KB, 4000h).
; -----------------------------------------------------------------------------

		include		"msx.asm"

		org		0x4000
		rom_header	entry_point

; -----------------------------------------------------------------------------
;	entry point
; -----------------------------------------------------------------------------
entry_point::
		di
		ld		sp, 0xf380

		; SCREEN 5
		ld		a, 5
		call		CHGMOD

		; ---- 1. HMMV: fill the whole screen with color 4 (dark blue)
		ld		hl, 0			; DX = 0
		ld		b, 36
		call		vdp_reg16
		ld		hl, 0			; DY = 0
		ld		b, 38
		call		vdp_reg16
		ld		hl, 256			; NX = 256
		ld		b, 40
		call		vdp_reg16
		ld		hl, 212			; NY = 212
		ld		b, 42
		call		vdp_reg16
		ld		a, 0x44			; CLR: color 4 in both nibbles
		ld		b, 44			;      (HMMV writes raw bytes)
		call		vdp_reg
		ld		a, 0			; ARG = 0 (to the right / down)
		ld		b, 45
		call		vdp_reg
		ld		a, 0xc0			; HMMV
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; ---- 2. HMMV: fill a box (32,24)-(111,79) with color 8 (red)
		ld		hl, 32			; DX = 32
		ld		b, 36
		call		vdp_reg16
		ld		hl, 24			; DY = 24
		ld		b, 38
		call		vdp_reg16
		ld		hl, 80			; NX = 80
		ld		b, 40
		call		vdp_reg16
		ld		hl, 56			; NY = 56
		ld		b, 42
		call		vdp_reg16
		ld		a, 0x88			; CLR: color 8 in both nibbles
		ld		b, 44
		call		vdp_reg
		ld		a, 0xc0			; HMMV (ARG is still 0)
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; ---- 3. LINE: cross (X) inside the box, color 11
		; diagonal 1: (32,24) -> (111,79)
		ld		hl, 32			; DX = 32
		ld		b, 36
		call		vdp_reg16
		ld		hl, 24			; DY = 24
		ld		b, 38
		call		vdp_reg16
		ld		hl, 79			; NX = 79 (long side)
		ld		b, 40
		call		vdp_reg16
		ld		hl, 55			; NY = 55 (short side)
		ld		b, 42
		call		vdp_reg16
		ld		a, 11			; CLR = 11
		ld		b, 44
		call		vdp_reg
		ld		a, 0x00			; ARG: MAJ=0 (X is the long axis)
		ld		b, 45
		call		vdp_reg
		ld		a, 0x70			; LINE, LOP = IMP
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; diagonal 2: (111,24) -> (32,79)  (DIX=1: extends to the left)
		ld		hl, 111			; DX = 111
		ld		b, 36
		call		vdp_reg16
		ld		hl, 24			; DY = 24
		ld		b, 38
		call		vdp_reg16
		ld		hl, 79			; NX = 79
		ld		b, 40
		call		vdp_reg16
		ld		hl, 55			; NY = 55
		ld		b, 42
		call		vdp_reg16
		ld		a, 11			; CLR = 11
		ld		b, 44
		call		vdp_reg
		ld		a, 0x04			; ARG: MAJ=0, DIX=1
		ld		b, 45
		call		vdp_reg
		ld		a, 0x70			; LINE
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; ---- 4. LINE: frame around the box, color 15
		; top edge: (32,24) -> (111,24)
		ld		hl, 32
		ld		b, 36
		call		vdp_reg16
		ld		hl, 24
		ld		b, 38
		call		vdp_reg16
		ld		hl, 79			; NX = 79 (long side)
		ld		b, 40
		call		vdp_reg16
		ld		hl, 0			; NY = 0 (short side)
		ld		b, 42
		call		vdp_reg16
		ld		a, 15			; CLR = 15
		ld		b, 44
		call		vdp_reg
		ld		a, 0x00			; ARG: MAJ=0 (X is the long axis)
		ld		b, 45
		call		vdp_reg
		ld		a, 0x70			; LINE
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; bottom edge: (32,79) -> (111,79)
		ld		hl, 32
		ld		b, 36
		call		vdp_reg16
		ld		hl, 79
		ld		b, 38
		call		vdp_reg16
		ld		hl, 79
		ld		b, 40
		call		vdp_reg16
		ld		hl, 0
		ld		b, 42
		call		vdp_reg16
		ld		a, 15
		ld		b, 44
		call		vdp_reg
		ld		a, 0x70
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; left edge: (32,24) -> (32,79)  (MAJ=0: Y is the long axis,
		;                                 so NX takes the Y count)
		ld		hl, 32
		ld		b, 36
		call		vdp_reg16
		ld		hl, 24
		ld		b, 38
		call		vdp_reg16
		ld		hl, 55			; NX = 55 (long side = Y count)
		ld		b, 40
		call		vdp_reg16
		ld		hl, 0			; NY = 0
		ld		b, 42
		call		vdp_reg16
		ld		a, 15
		ld		b, 44
		call		vdp_reg
		ld		a, 0x01			; ARG: MAJ=1 (Y is the long axis)
		ld		b, 45
		call		vdp_reg
		ld		a, 0x70
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; right edge: (111,24) -> (111,79)
		ld		hl, 111
		ld		b, 36
		call		vdp_reg16
		ld		hl, 24
		ld		b, 38
		call		vdp_reg16
		ld		hl, 55
		ld		b, 40
		call		vdp_reg16
		ld		hl, 0
		ld		b, 42
		call		vdp_reg16
		ld		a, 15
		ld		b, 44
		call		vdp_reg
		ld		a, 0x70
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; ---- 5. LMMM: copy the box (32,24,80x56) to (144,120)
		ld		hl, 32			; SX = 32
		ld		b, 32
		call		vdp_reg16
		ld		hl, 24			; SY = 24
		ld		b, 34
		call		vdp_reg16
		ld		hl, 144			; DX = 144
		ld		b, 36
		call		vdp_reg16
		ld		hl, 120			; DY = 120
		ld		b, 38
		call		vdp_reg16
		ld		hl, 80			; NX = 80
		ld		b, 40
		call		vdp_reg16
		ld		hl, 56			; NY = 56
		ld		b, 42
		call		vdp_reg16
		ld		a, 0			; ARG = 0
		ld		b, 45
		call		vdp_reg
		ld		a, 0x90			; LMMM, LOP = IMP
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

main_loop::
		jr		main_loop

; -----------------------------------------------------------------------------
;	write one VDP control register (direct register write)
;	in:  A = value, B = register number
; -----------------------------------------------------------------------------
vdp_reg::
		out		[0x99], a
		ld		a, b
		set		7, a
		out		[0x99], a
		ret

; -----------------------------------------------------------------------------
;	write a 16-bit command parameter
;	in:  HL = value, B = register number of the low byte
; -----------------------------------------------------------------------------
vdp_reg16::
		ld		a, l
		call		vdp_reg
		inc		b
		ld		a, h
		call		vdp_reg
		ret

; -----------------------------------------------------------------------------
;	wait until the running VDP command finishes (S#2 CE bit = 0)
; -----------------------------------------------------------------------------
vdp_wait::
		ld		a, 2			; select status register 2
		ld		b, 15
		call		vdp_reg
vdp_wait_loop:
		in		a, [0x99]
		bit		0, a			; CE bit
		jr		nz, vdp_wait_loop
		xor		a, a			; restore S#0 selection
		ld		b, 15
		call		vdp_reg
		ret
