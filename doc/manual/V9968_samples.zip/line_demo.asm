; -----------------------------------------------------------------------------
;	line_demo.asm -- Line interrupt demonstration (V9968 User's Manual, ch.10)
;
;	SCREEN 5 (Graphic 4). Sixteen vertical bars are drawn, one per
;	palette color. R#19 is set to line 106 (the middle of the
;	screen). The main loop then rewrites the whole palette twice
;	per frame:
;
;	  - at the V-blank flag (S#0 F bit) it loads palette A,
;	  - when the line-interrupt flag (S#1 FH bit) reports that the
;	    raster reached line 106, it loads palette B (palette A
;	    with the R and B components swapped).
;
;	The upper half of the screen therefore shows palette A and
;	the lower half palette B: a split-screen effect.
;
;	No interrupt routine is used: the FH flag is set when the
;	raster reaches the R#19 line whether or not IE1 is enabled,
;	so the flag can simply be polled, as done here. (A cartridge
;	ROM cannot replace the 0038h vector anyway, because page 0
;	belongs to the BIOS.)
;
;	Assemble with zma, run as a cartridge ROM (16 KB, 4000h).
; -----------------------------------------------------------------------------

		include		"msx.asm"

		org		0x4000
		rom_header	entry_point

; -----------------------------------------------------------------------------
;	entry point
; -----------------------------------------------------------------------------
entry_point::
		di
		ld		sp, 0xf380

		; SCREEN 5
		ld		a, 5
		call		CHGMOD

		; ---- draw 16 vertical bars (16 dots wide, full height)
		ld		de, 0			; DX = 0
		ld		c, 0			; color = 0
bar_loop:
		push		bc
		push		de
		ex		de, hl			; DX
		ld		b, 36
		call		vdp_reg16
		ld		hl, 0			; DY = 0
		ld		b, 38
		call		vdp_reg16
		ld		hl, 16			; NX = 16
		ld		b, 40
		call		vdp_reg16
		ld		hl, 212			; NY = 212
		ld		b, 42
		call		vdp_reg16
		pop		de
		pop		bc
		ld		a, c			; CLR = color in both nibbles
		add		a, a
		add		a, a
		add		a, a
		add		a, a
		or		a, c
		ld		b, 44
		call		vdp_reg
		ld		a, 0			; ARG = 0
		ld		b, 45
		call		vdp_reg
		ld		a, 0xc0			; HMMV
		ld		b, 46
		call		vdp_reg
		call		vdp_wait
		; next bar
		ld		a, e
		add		a, 16
		ld		e, a
		inc		c
		ld		a, c
		cp		a, 16
		jr		nz, bar_loop

		; ---- line interrupt on line 106 (middle of the screen)
		ld		a, 106
		ld		b, 19
		call		vdp_reg

		; ---- load palette A once, then start the split loop
		ld		hl, palette_a
		call		apply_palette

split_loop::
		; wait for the V-blank flag F (S#0 bit7)
wait_f:
		in		a, [0x99]
		bit		7, a
		jr		z, wait_f
		; top half: palette A
		ld		hl, palette_a
		call		apply_palette
		; select S#1 and wait for the line-interrupt flag FH (bit0)
		ld		a, 1
		ld		b, 15
		call		vdp_reg
wait_fh:
		in		a, [0x99]
		bit		0, a
		jr		z, wait_fh
		; bottom half: palette B
		ld		hl, palette_b
		call		apply_palette
		; restore the S#0 selection
		xor		a, a
		ld		b, 15
		call		vdp_reg
		jr		split_loop

; -----------------------------------------------------------------------------
;	load all 16 palette entries
;	in:  HL = palette table (16 entries x 2 bytes)
; -----------------------------------------------------------------------------
apply_palette::
		push		hl
		ld		a, 0			; R#16 = 0 (start entry)
		ld		b, 16
		call		vdp_reg
		pop		hl
		ld		b, 32			; 16 entries x 2 bytes
apply_palette_loop:
		ld		a, [hl]
		out		[0x9a], a		; palette port (auto-increments)
		inc		hl
		djnz		apply_palette_loop
		ret

; -----------------------------------------------------------------------------
;	palette data: 16 entries, normal format (EPAL = 0)
;	1st byte = [0][R2..R0][0][B2..B0], 2nd byte = G (3 bits)
;	palette A: the color ramp of ch.7's pal_demo.
;	palette B: the same ramp with R and B swapped.
; -----------------------------------------------------------------------------
palette_a:
		db		0x00, 0x00		;  0: R=0 G=0 B=0 (black)
		db		0x13, 0x00		;  1: R=1 G=0 B=3
		db		0x24, 0x00		;  2: R=2 G=0 B=4
		db		0x35, 0x01		;  3: R=3 G=1 B=5
		db		0x46, 0x01		;  4: R=4 G=1 B=6
		db		0x56, 0x02		;  5: R=5 G=2 B=6
		db		0x67, 0x03		;  6: R=6 G=3 B=7
		db		0x76, 0x04		;  7: R=7 G=4 B=6
		db		0x74, 0x05		;  8: R=7 G=5 B=4
		db		0x72, 0x06		;  9: R=7 G=6 B=2
		db		0x71, 0x07		; 10: R=7 G=7 B=1
		db		0x51, 0x07		; 11: R=5 G=7 B=1
		db		0x32, 0x07		; 12: R=3 G=7 B=2
		db		0x13, 0x07		; 13: R=1 G=7 B=3
		db		0x36, 0x06		; 14: R=3 G=6 B=6
		db		0x77, 0x07		; 15: R=7 G=7 B=7 (white)

palette_b:
		db		0x00, 0x00		;  0: R=0 G=0 B=0 (black)
		db		0x31, 0x00		;  1: R=3 G=0 B=1
		db		0x42, 0x00		;  2: R=4 G=0 B=2
		db		0x53, 0x01		;  3: R=5 G=1 B=3
		db		0x64, 0x01		;  4: R=6 G=1 B=4
		db		0x65, 0x02		;  5: R=6 G=2 B=5
		db		0x76, 0x03		;  6: R=7 G=3 B=6
		db		0x67, 0x04		;  7: R=6 G=4 B=7
		db		0x47, 0x05		;  8: R=4 G=5 B=7
		db		0x27, 0x06		;  9: R=2 G=6 B=7
		db		0x17, 0x07		; 10: R=1 G=7 B=7
		db		0x15, 0x07		; 11: R=1 G=7 B=5
		db		0x23, 0x07		; 12: R=2 G=7 B=3
		db		0x31, 0x07		; 13: R=3 G=7 B=1
		db		0x63, 0x06		; 14: R=6 G=6 B=3
		db		0x77, 0x07		; 15: R=7 G=7 B=7 (white)

; -----------------------------------------------------------------------------
;	write one VDP control register (direct register write)
;	in:  A = value, B = register number
; -----------------------------------------------------------------------------
vdp_reg::
		out		[0x99], a
		ld		a, b
		set		7, a
		out		[0x99], a
		ret

; -----------------------------------------------------------------------------
;	write a 16-bit command parameter
;	in:  HL = value, B = register number of the low byte
; -----------------------------------------------------------------------------
vdp_reg16::
		ld		a, l
		call		vdp_reg
		inc		b
		ld		a, h
		call		vdp_reg
		ret

; -----------------------------------------------------------------------------
;	wait until the running VDP command finishes (S#2 CE bit = 0)
; -----------------------------------------------------------------------------
vdp_wait::
		ld		a, 2			; select status register 2
		ld		b, 15
		call		vdp_reg
vdp_wait_loop:
		in		a, [0x99]
		bit		0, a			; CE bit
		jr		nz, vdp_wait_loop
		xor		a, a			; restore S#0 selection
		ld		b, 15
		call		vdp_reg
		ret
