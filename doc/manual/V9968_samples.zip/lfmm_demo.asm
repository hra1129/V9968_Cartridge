; -----------------------------------------------------------------------------
;	lfmm_demo.asm -- LFMM font drawing demonstration
;	                 (V9968 User's Manual, ch.8)
;
;	SCREEN 5 (Graphic 4). A small 8x16 font for the characters
;	"V", "9", "6", "8" is placed in VRAM (page 1, address 8000h),
;	and LFMM expands it onto the screen as the string "V9968".
;	The same string is drawn a second time with DIY = 1, which
;	flips it upside down.
;
;	LFMM key points shown here:
;	  - SX/SY are not coordinates: R#32..R#34 hold the font data
;	    address (3-byte little endian in the 256 KB space),
;	    R#35 is unused and set to 0.
;	  - NX counts CHARACTERS, not dots (5 characters here).
;	  - the foreground color is set in R#44 and the background
;	    color in R#12 before the command starts.
;	  - font data is 1 bit per dot, one byte per character row,
;	    character by character (16 rows of "V", then 16 of "9", ...).
;
;	LFMM is a V9968 extended command: extended mode (V58 = 0) is
;	required, and the extended registers R#20/R#21 are locked at
;	reset, so the lock is released first (Port#4 bit7 = 0).
;
;	Assemble with zma, run as a cartridge ROM (16 KB, 4000h).
; -----------------------------------------------------------------------------

		include		"msx.asm"

		org		0x4000
		rom_header	entry_point

; -----------------------------------------------------------------------------
;	entry point
; -----------------------------------------------------------------------------
entry_point::
		di
		ld		sp, 0xf380

		; release the extended-register lock (Port#4 bit7 = 0)
		xor		a, a
		out		[0x9c], a

		; SCREEN 5
		ld		a, 5
		call		CHGMOD

		; extended mode: R#21 bit0 (V58) = 0
		ld		a, 0x3a
		ld		b, 21
		call		vdp_reg

		; ---- fill the whole screen with color 4 (dark blue)
		ld		hl, 0
		ld		b, 36
		call		vdp_reg16
		ld		hl, 0
		ld		b, 38
		call		vdp_reg16
		ld		hl, 256
		ld		b, 40
		call		vdp_reg16
		ld		hl, 212
		ld		b, 42
		call		vdp_reg16
		ld		a, 0x44			; CLR: color 4 in both nibbles
		ld		b, 44
		call		vdp_reg
		ld		a, 0			; ARG = 0
		ld		b, 45
		call		vdp_reg
		ld		a, 0xc0			; HMMV
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; ---- font data -> VRAM 8000h (page 1, not displayed)
		ld		de, 0x8000
		ld		hl, font_data
		ld		bc, 80			; 5 characters x 16 rows
		call		vram_copy

		; ---- LFMM #1: draw "V9968" at (28, 48), upright
		ld		hl, 0x8000		; font address -> R#32 (low), R#33
		ld		b, 32
		call		vdp_reg16
		ld		hl, 0			; R#34 = address bits 17..16 = 0
		ld		b, 34			; (R#35 = 0 as well, it is unused)
		call		vdp_reg16
		ld		hl, 28			; DX = 28
		ld		b, 36
		call		vdp_reg16
		ld		hl, 48			; DY = 48
		ld		b, 38
		call		vdp_reg16
		ld		hl, 5			; NX = 5 (characters!)
		ld		b, 40
		call		vdp_reg16
		ld		hl, 16			; NY = 16 (font height)
		ld		b, 42
		call		vdp_reg16
		ld		a, 15			; foreground color -> R#44
		ld		b, 44
		call		vdp_reg
		ld		a, 4			; background color -> R#12
		ld		b, 12
		call		vdp_reg
		ld		a, 0			; ARG = 0
		ld		b, 45
		call		vdp_reg
		ld		a, 0x10			; LFMM, LOP = IMP
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; ---- LFMM #2: the same string at (28, 144), flipped (DIY = 1)
		; with DIY = 1 the drawing proceeds upward from DY, so DY is
		; the BOTTOM edge of the flipped string.
		ld		hl, 0x8000		; font address (set again: the
		ld		b, 32			; command registers are rewritten
		call		vdp_reg16		; by each command execution)
		ld		hl, 0
		ld		b, 34
		call		vdp_reg16
		ld		hl, 28			; DX = 28
		ld		b, 36
		call		vdp_reg16
		ld		hl, 144			; DY = 144 (bottom edge)
		ld		b, 38
		call		vdp_reg16
		ld		hl, 5			; NX = 5
		ld		b, 40
		call		vdp_reg16
		ld		hl, 16			; NY = 16
		ld		b, 42
		call		vdp_reg16
		ld		a, 15			; foreground color -> R#44
		ld		b, 44
		call		vdp_reg
		ld		a, 4			; background color -> R#12
		ld		b, 12
		call		vdp_reg
		ld		a, 0x08			; ARG: DIY = 1 (draw upward, flipped)
		ld		b, 45
		call		vdp_reg
		ld		a, 0x10			; LFMM, LOP = IMP
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

main_loop::
		jr		main_loop

; -----------------------------------------------------------------------------
;	font data: 8x16 glyphs, 1 byte per row, MSB = leftmost dot.
;	the string "V9968" is stored character by character:
;	"V" (16 rows), "9", "9", "6", "8".
; -----------------------------------------------------------------------------
font_data:
		; "V"
		db		0x81, 0x81, 0x81, 0x81, 0x81, 0x81, 0x81, 0x81
		db		0x42, 0x42, 0x42, 0x42, 0x24, 0x24, 0x18, 0x18
		; "9"
		db		0x3c, 0x66, 0x66, 0x66, 0x66, 0x3e, 0x06, 0x06
		db		0x3c, 0x66, 0x66, 0x66, 0x66, 0x66, 0x3c, 0x00
		; "9" (same glyph again)
		db		0x3c, 0x66, 0x66, 0x66, 0x66, 0x3e, 0x06, 0x06
		db		0x3c, 0x66, 0x66, 0x66, 0x66, 0x66, 0x3c, 0x00
		; "6"
		db		0x3c, 0x66, 0x66, 0x60, 0x60, 0x60, 0x7c, 0x66
		db		0x66, 0x66, 0x66, 0x66, 0x3c, 0x00, 0x00, 0x00
		; "8"
		db		0x3c, 0x66, 0x66, 0x66, 0x3c, 0x3c, 0x66, 0x66
		db		0x66, 0x66, 0x66, 0x66, 0x3c, 0x00, 0x00, 0x00

; -----------------------------------------------------------------------------
;	write one VDP control register (direct register write)
;	in:  A = value, B = register number
; -----------------------------------------------------------------------------
vdp_reg::
		out		[0x99], a
		ld		a, b
		set		7, a
		out		[0x99], a
		ret

; -----------------------------------------------------------------------------
;	write a 16-bit command parameter
;	in:  HL = value, B = register number of the low byte
; -----------------------------------------------------------------------------
vdp_reg16::
		ld		a, l
		call		vdp_reg
		inc		b
		ld		a, h
		call		vdp_reg
		ret

; -----------------------------------------------------------------------------
;	wait until the running VDP command finishes (S#2 CE bit = 0)
; -----------------------------------------------------------------------------
vdp_wait::
		ld		a, 2			; select status register 2
		ld		b, 15
		call		vdp_reg
vdp_wait_loop:
		in		a, [0x99]
		bit		0, a			; CE bit
		jr		nz, vdp_wait_loop
		xor		a, a			; restore S#0 selection
		ld		b, 15
		call		vdp_reg
		ret

; -----------------------------------------------------------------------------
;	copy data to VRAM
;	in:  DE = VRAM address, HL = source address, BC = byte count
; -----------------------------------------------------------------------------
vram_copy::
		push		hl
		push		bc
		ex		de, hl			; HL = VRAM address
		ld		a, h			; R#14 = address bits 16..14
		and		a, 0xc0
		rlca
		rlca
		ld		b, 14
		call		vdp_reg
		ld		a, l			; low byte of the address
		out		[0x99], a
		ld		a, h			; high byte + write flag (bit6)
		and		a, 0x3f
		set		6, a
		out		[0x99], a
		pop		bc
		pop		hl
vram_copy_loop:
		ld		a, [hl]
		out		[0x98], a
		inc		hl
		dec		bc
		ld		a, b
		or		a, c
		jr		nz, vram_copy_loop
		ret
