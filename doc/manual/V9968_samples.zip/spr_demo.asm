; -----------------------------------------------------------------------------
;	spr_demo.asm -- Sprite mode 2 demonstration (V9968 User's Manual, ch.6)
;
;	SCREEN 5 (Graphic 4, sprite mode 2). Four 16x16 "ball" sprites are
;	shown. The leftmost ball uses a different color for every line --
;	the feature that distinguishes sprite mode 2: colors are not set
;	per sprite, but per line, in the sprite color table.
;	The other three balls use a single color for all 16 lines.
;
;	VRAM layout (SCREEN 5 defaults):
;	  sprite pattern table   : 7800h
;	  sprite attribute table : 7600h
;	  sprite color table     : 7400h (attribute base with A9 forced to 0)
;
;	Assemble with zma, run as a cartridge ROM (16 KB, 4000h).
; -----------------------------------------------------------------------------

		include		"msx.asm"

		org		0x4000
		rom_header	entry_point

; -----------------------------------------------------------------------------
;	entry point
; -----------------------------------------------------------------------------
entry_point::
		di
		ld		sp, 0xf380

		; SCREEN 5
		ld		a, 5
		call		CHGMOD

		; sprite size 16x16: set SI bit of R#1 (keep BL / IE bits)
		ld		a, 0x62
		ld		b, 1
		call		vdp_reg

		; backdrop color = 4 (dark blue)
		ld		a, 0x04
		ld		b, 7
		call		vdp_reg

		; ---- sprite pattern -> 7800h
		ld		de, 0x7800
		ld		hl, pattern_table
		ld		bc, 32			; 1 pattern x 32 bytes
		call		vram_copy

		; ---- sprite attributes -> 7600h
		ld		de, 0x7600
		ld		hl, attribute_table
		ld		bc, 20			; 5 planes x 4 bytes
		call		vram_copy

		; ---- sprite colors -> 7400h
		ld		de, 0x7400
		ld		hl, color_table
		ld		bc, 64			; 4 planes x 16 bytes
		call		vram_copy

main_loop::
		jr		main_loop

; -----------------------------------------------------------------------------
;	sprite pattern 0: ball (16x16)
;	bytes 0..15 = left half (columns 0..7), bytes 16..31 = right half
; -----------------------------------------------------------------------------
pattern_table:
		db		0x07, 0x0f, 0x1f, 0x3f, 0x3f, 0x7f, 0x7f, 0x7f
		db		0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x3f, 0x07
		db		0xe0, 0xf0, 0xf8, 0xfc, 0xfc, 0xfe, 0xfe, 0xfe
		db		0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfe, 0xfc, 0xe0

; -----------------------------------------------------------------------------
;	sprite attribute table: Y, X, pattern number, (unused in mode 2)
; -----------------------------------------------------------------------------
attribute_table:
		db		60, 40, 0, 0		; plane 0: rainbow ball
		db		40, 110, 0, 0		; plane 1: yellow ball
		db		90, 180, 0, 0		; plane 2: light blue ball
		db		140, 70, 0, 0		; plane 3: magenta ball
		db		216, 0, 0, 0		; plane 4: Y=216 ends the list

; -----------------------------------------------------------------------------
;	sprite color table: 16 bytes per plane, one byte per pattern line.
;	plane 0 gives every line a different color, so the ball shows
;	horizontal stripes. planes 1..3 repeat a single color 16 times.
; -----------------------------------------------------------------------------
color_table:
		; plane 0: a different color on every line
		db		0x06, 0x08, 0x08, 0x09, 0x09, 0x0b, 0x0b, 0x0a
		db		0x0a, 0x0c, 0x02, 0x02, 0x03, 0x03, 0x05, 0x05
		; plane 1: color 11 (light yellow) on all lines
		db		0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b
		db		0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b
		; plane 2: color 5 (light blue) on all lines
		db		0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05
		db		0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05
		; plane 3: color 13 (magenta) on all lines
		db		0x0d, 0x0d, 0x0d, 0x0d, 0x0d, 0x0d, 0x0d, 0x0d
		db		0x0d, 0x0d, 0x0d, 0x0d, 0x0d, 0x0d, 0x0d, 0x0d

; -----------------------------------------------------------------------------
;	write one VDP control register (direct register write)
;	in:  A = value, B = register number
; -----------------------------------------------------------------------------
vdp_reg::
		out		[0x99], a
		ld		a, b
		set		7, a
		out		[0x99], a
		ret

; -----------------------------------------------------------------------------
;	copy data to VRAM
;	in:  DE = VRAM address, HL = source address, BC = byte count
; -----------------------------------------------------------------------------
vram_copy::
		push		hl
		push		bc
		ex		de, hl			; HL = VRAM address
		ld		a, h			; R#14 = address bits 16..14
		and		a, 0xc0
		rlca
		rlca
		ld		b, 14
		call		vdp_reg
		ld		a, l			; low byte of the address
		out		[0x99], a
		ld		a, h			; high byte + write flag (bit6)
		and		a, 0x3f
		set		6, a
		out		[0x99], a
		pop		bc
		pop		hl
vram_copy_loop:
		ld		a, [hl]
		out		[0x98], a
		inc		hl
		dec		bc
		ld		a, b
		or		a, c
		jr		nz, vram_copy_loop
		ret
