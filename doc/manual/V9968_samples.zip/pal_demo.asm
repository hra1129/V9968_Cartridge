; -----------------------------------------------------------------------------
;	pal_demo.asm -- Palette demonstration (V9968 User's Manual, ch.7)
;
;	SCREEN 5 (Graphic 4). All 16 palette entries are rewritten with a
;	custom color ramp (via R#16 + palette port), then 16 vertical bars
;	are drawn with HMMV, one bar per palette color, so the effect of
;	the palette change is directly visible.
;
;	Assemble with zma, run as a cartridge ROM (16 KB, 4000h).
; -----------------------------------------------------------------------------

		include		"msx.asm"

		org		0x4000
		rom_header	entry_point

; -----------------------------------------------------------------------------
;	entry point
; -----------------------------------------------------------------------------
entry_point::
		di
		ld		sp, 0xf380

		; SCREEN 5
		ld		a, 5
		call		CHGMOD

		; backdrop = color 0 (color 0 is transparent in graphic modes,
		; so the background shows the backdrop color = palette entry 0)
		ld		a, 0x00
		ld		b, 7
		call		vdp_reg

		; ---- rewrite palette entries 0..15
		ld		a, 0			; R#16 = 0 (start entry)
		ld		b, 16
		call		vdp_reg
		ld		hl, palette_table
		ld		b, 32			; 16 entries x 2 bytes
palette_loop:
		ld		a, [hl]
		out		[0x9a], a		; palette port (auto-increments)
		inc		hl
		djnz		palette_loop

		; ---- fill the background with color 0
		ld		hl, 0
		ld		b, 36
		call		vdp_reg16
		ld		hl, 0
		ld		b, 38
		call		vdp_reg16
		ld		hl, 256
		ld		b, 40
		call		vdp_reg16
		ld		hl, 212
		ld		b, 42
		call		vdp_reg16
		ld		a, 0x00			; CLR: color 0 in both nibbles
		ld		b, 44
		call		vdp_reg
		ld		a, 0			; ARG = 0
		ld		b, 45
		call		vdp_reg
		ld		a, 0xc0			; HMMV
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		; ---- draw 16 vertical bars, bar i filled with color i
		; E = color / bar index (kept in E: the helpers only use A,B,HL)
		ld		e, 0
bar_loop:
		ld		a, e			; DX = index * 16
		ld		h, 0
		ld		l, a
		sla		l
		sla		l
		sla		l
		sla		l
		ld		b, 36
		call		vdp_reg16
		ld		hl, 32			; DY = 32
		ld		b, 38
		call		vdp_reg16
		ld		hl, 16			; NX = 16
		ld		b, 40
		call		vdp_reg16
		ld		hl, 128			; NY = 128
		ld		b, 42
		call		vdp_reg16
		ld		a, e			; CLR: same color in both nibbles
		sla		a
		sla		a
		sla		a
		sla		a
		or		a, e
		ld		b, 44
		call		vdp_reg
		ld		a, 0xc0			; HMMV (ARG is still 0)
		ld		b, 46
		call		vdp_reg
		call		vdp_wait

		inc		e
		ld		a, e
		cp		a, 16
		jr		nz, bar_loop

main_loop::
		jr		main_loop

; -----------------------------------------------------------------------------
;	palette data: 16 entries, normal format (EPAL = 0)
;	1st byte = [0][R2..R0][0][B2..B0], 2nd byte = G (3 bits)
;	a ramp that runs from black through blue/magenta/red/yellow/green
;	to white, so all three components change across the bars.
; -----------------------------------------------------------------------------
palette_table:
		db		0x00, 0x00		;  0: R=0 G=0 B=0 (black)
		db		0x13, 0x00		;  1: R=1 G=0 B=3
		db		0x24, 0x00		;  2: R=2 G=0 B=4
		db		0x35, 0x01		;  3: R=3 G=1 B=5
		db		0x46, 0x01		;  4: R=4 G=1 B=6
		db		0x56, 0x02		;  5: R=5 G=2 B=6
		db		0x67, 0x03		;  6: R=6 G=3 B=7
		db		0x76, 0x04		;  7: R=7 G=4 B=6
		db		0x74, 0x05		;  8: R=7 G=5 B=4
		db		0x72, 0x06		;  9: R=7 G=6 B=2
		db		0x71, 0x07		; 10: R=7 G=7 B=1
		db		0x51, 0x07		; 11: R=5 G=7 B=1
		db		0x32, 0x07		; 12: R=3 G=7 B=2
		db		0x13, 0x07		; 13: R=1 G=7 B=3
		db		0x36, 0x06		; 14: R=3 G=6 B=6
		db		0x77, 0x07		; 15: R=7 G=7 B=7 (white)

; -----------------------------------------------------------------------------
;	write one VDP control register (direct register write)
;	in:  A = value, B = register number
; -----------------------------------------------------------------------------
vdp_reg::
		out		[0x99], a
		ld		a, b
		set		7, a
		out		[0x99], a
		ret

; -----------------------------------------------------------------------------
;	write a 16-bit command parameter
;	in:  HL = value, B = register number of the low byte
; -----------------------------------------------------------------------------
vdp_reg16::
		ld		a, l
		call		vdp_reg
		inc		b
		ld		a, h
		call		vdp_reg
		ret

; -----------------------------------------------------------------------------
;	wait until the running VDP command finishes (S#2 CE bit = 0)
; -----------------------------------------------------------------------------
vdp_wait::
		ld		a, 2			; select status register 2
		ld		b, 15
		call		vdp_reg
vdp_wait_loop:
		in		a, [0x99]
		bit		0, a			; CE bit
		jr		nz, vdp_wait_loop
		xor		a, a			; restore S#0 selection
		ld		b, 15
		call		vdp_reg
		ret
